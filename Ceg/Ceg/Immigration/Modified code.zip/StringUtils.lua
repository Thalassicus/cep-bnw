-- StringUtils.lua
-- Author: Afforess
-- DateCreated: 10/7/2010 8:42:04 PM
--------------------------------------------------------------

function tableToString(tbl, size, depth, separators, count)
	local str = "";
	if (depth > 1) then
		for i = 1, size, 1 do
			if tbl[i] then
				str = str..tableToString(tbl[i], sizeOfTable(tbl[i]), depth-1, separators, count+1)..separators[count];
			end
		end
	elseif depth == 1 then
		for i = 1, size, 1 do
			if tbl[i] then
				str = str..tbl[i]..separators[count];
			end
		end
		str = string.sub(str, 1, string.len(str)-1);
	end
	return str;
end

function stringToTable(str, size, depth, separators, count)
	local tbl = splitString(str, separators[count]);
	if depth > 1 then
		for i = 1, size, 1 do
			tbl[i] = stringToTable(tbl[i], sizeOfTable(tbl[i]), depth-1, separators, count+1);
		end
	end
	return tbl;
end

function sizeOfTable(table)
	local size = 1;
	while true do
		if  not table[size] then
			return size - 1;
		end
		size = size+1;
	end
	return 0;
end

function splitString(str, pat)
   local t = {}
   local fpat = "(.-)" .. pat
   local last_end = 1
   local s, e, cap = str:find(fpat, 1)
   while s do
      if s ~= 1 or cap ~= "" then
		if tonumber(cap) then
			cap = tonumber(cap);
		end
		 table.insert(t,cap)
      end
      last_end = e+1
      s, e, cap = str:find(fpat, last_end)
   end
   if last_end <= #str then
      cap = str:sub(last_end)
      table.insert(t, cap)
   end
   return t
end